package com.example.groupchatapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.groupchatapp.app.Config;
import com.example.groupchatapp.appconstants.AppConstants;
import com.example.groupchatapp.models.ChatModel;
import com.example.groupchatapp.util.NotificationUtils;
import com.example.groupchatapp.util.RequestForWebservice;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by appyb_000 on 12/11/2016.
 */

public class FcmActivity extends AppCompatActivity implements View.OnClickListener, FragmentDrawer.FragmentDrawerListener  {
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    RecyclerView chatlist;
    ArrayList<ChatModel> chats;
    Chatadapter mAdapter;
    EditText chattext;
    ImageButton sendmessage;
    private Toolbar mToolbar;
    FragmentDrawer drawerFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fcmchat);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        drawerFragment = (FragmentDrawer)
                getFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), mToolbar);
        drawerFragment.setDrawerListener(this);

        chats = new ArrayList<>();
        chatlist = (RecyclerView) findViewById(R.id.chatlist);
        chattext = (EditText) findViewById(R.id.chattext);
        sendmessage = (ImageButton) findViewById(R.id.sendmessage);

        sendmessage.setOnClickListener(this);

        mAdapter = new Chatadapter();
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        chatlist.setLayoutManager(mLayoutManager);
        chatlist.setItemAnimator(new DefaultItemAnimator());
        chatlist.setAdapter(mAdapter);

        mRegistrationBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                // checking for type intent filter
                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                    // gcm successfully registered
                    // now subscribe to `global` topic to receive app wide notifications
                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);

                    displayFirebaseRegId();

                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                    // new push notification is received


                    if (intent.getStringExtra(AppConstants.FROM_ID).equalsIgnoreCase(Config.FROM_ID))
                        return;


                    if (intent.getStringExtra(AppConstants.ONLINE_STATUS).toString().trim().length()>0) {
                        if (intent.getStringExtra(AppConstants.ONLINE_STATUS).equalsIgnoreCase("Yes")){
                            drawerFragment.setOnlineuser(intent.getStringExtra(AppConstants.NAME));
                            Login();
                        }
                        else
                            drawerFragment.removeUser(intent.getStringExtra(AppConstants.NAME));
                    }else{

                        ChatModel model = new ChatModel();
                        model.setFrom_id(intent.getStringExtra(AppConstants.FROM_ID));
                        model.setTo_id(intent.getStringExtra(AppConstants.TO_ID));
                        model.setMsgType(1);
                        try {
                            String sDecoded = URLDecoder.decode(intent.getStringExtra(AppConstants.MESSAGE), "UTF-8");
                            model.setMsg(sDecoded);
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }

                        model.setName(intent.getStringExtra(AppConstants.NAME));

                        chats.add(model);

                        mAdapter.notifyDataSetChanged();

                        chatlist.scrollToPosition(chats.size()-1);
                    }


                    /*String message = intent.getStringExtra("message");

                    Toast.makeText(getApplicationContext(), "Push notification: " + message, Toast.LENGTH_LONG).show();*/

                }
            }
        };

        drawerFragment.setOnlineuser("You");

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sendmessage:
                String msg = chattext.getText().toString().trim();
                if (msg != null && msg.length() > 0) {
                    SendTextmessage(msg);
                    chattext.setText("");

                    ChatModel model = new ChatModel();
                    model.setFrom_id(Config.FROM_ID);
                    model.setTo_id(Config.TO_ID);
                    model.setMsgType(2);
                    model.setMsg(msg);
                    model.setName(Config.NAME);

                    chats.add(model);

                    mAdapter.notifyDataSetChanged();

                    chatlist.scrollToPosition(chats.size()-1);
                }
                break;
        }
    }


    // Fetches reg id from shared preferences
    // and displays on the screen
    private void displayFirebaseRegId() {
        SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
        String regId = pref.getString("regId", null);

        Log.e("", "Firebase reg id: " + regId);

        if (!TextUtils.isEmpty(regId)) {
            Log.d("Firebase Reg Id: ", " " + regId);
        } else
            Log.d("", "Firebase Reg Id is not received yet!");

    }


    @Override
    protected void onResume() {
        super.onResume();

       /* if (mAdView != null) {
            mAdView.resume();
        }*/
        // register GCM registration complete receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(Config.REGISTRATION_COMPLETE));

        // register new push message receiver
        // by doing this, the activity will be notified each time a new message arrives
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(Config.PUSH_NOTIFICATION));

        // clear the notification area when the app is opened
        NotificationUtils.clearNotifications(getApplicationContext());

        Login();
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        /*if (mAdView != null) {
            mAdView.pause();
        }*/
        Logout();
        super.onPause();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        Logout();
    }

    /**
     * Called before the activity is destroyed
     */



    @Override
    public void onDrawerItemSelected(View view, int position) {

    }

    /*********************
     * Adapter
     **************************/

    private class Chatadapter extends RecyclerView.Adapter<Chatadapter.MyViewHolder> {

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView singleMessage,name;

            public MyViewHolder(View itemView) {
                super(itemView);

                name= (TextView) itemView.findViewById(R.id.name);
                singleMessage = (TextView) itemView.findViewById(R.id.singleMessage);
            }
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            View convertview = null;

            if (viewType == 1) {
                convertview = inflater.inflate(R.layout.layout_incoming, parent, false);
            } else if (viewType == 2) {
                convertview = inflater.inflate(R.layout.layout_outgoing, parent, false);
            }

            return new MyViewHolder(convertview);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {

            ChatModel chatModel = chats.get(position);
            holder.singleMessage.setText(chatModel.getMsg());
            holder.name.setText(chatModel.getName());
        }

        @Override
        public int getItemViewType(int position) {

            ChatModel model = chats.get(position);

            if (model != null)
                return model.getMsgType();
            else
                return super.getItemViewType(position);
        }

        @Override
        public int getItemCount() {
            return chats.size();
        }
    }

    private void SendTextmessage(String chatmsg) {
        String sEncoded="";
        try {
            sEncoded = URLEncoder.encode(chatmsg, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        RequestForWebservice.RequestWebserice requestWebserice = new RequestForWebservice.RequestWebserice() {
            @Override
            public void OnWebserviceReply(String response) {
                Log.d("calculated", response);

                try {
                    Log.d("Data bagh re", "bagh" + response);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        RequestForWebservice req = new RequestForWebservice(requestWebserice, this);

        HashMap<String, String> parameters = new HashMap<>();
        parameters.put(AppConstants.FROM_ID, Config.FROM_ID);
        parameters.put(AppConstants.TO_ID, Config.TO_ID);
        parameters.put(AppConstants.MESSAGE, sEncoded);
        parameters.put(AppConstants.NAME, Config.NAME);

        req.SendAsyncMessage(parameters);
    }

    private void Login() {
        RequestForWebservice.RequestWebserice requestWebserice = new RequestForWebservice.RequestWebserice() {
            @Override
            public void OnWebserviceReply(String response) {
                Log.d("calculated", response);

                try {
                    Log.d("Data bagh re", "bagh" + response);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        RequestForWebservice req = new RequestForWebservice(requestWebserice, this);

        HashMap<String, String> parameters = new HashMap<>();
        parameters.put(AppConstants.FROM_ID, Config.FROM_ID);
        //parameters.put(AppConstants.TO_ID, Config.TO_ID);
        parameters.put(AppConstants.MESSAGE, "online");
        parameters.put(AppConstants.ONLINE_STATUS, "Yes");
        parameters.put(AppConstants.NAME, Config.NAME);

        req.UpdateUserStatus(parameters);
    }

    private void Logout() {
        RequestForWebservice.RequestWebserice requestWebserice = new RequestForWebservice.RequestWebserice() {
            @Override
            public void OnWebserviceReply(String response) {
                Log.d("calculated", response);

                try {
                    Log.d("Data bagh re", "bagh" + response);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        RequestForWebservice req = new RequestForWebservice(requestWebserice, this);

        HashMap<String, String> parameters = new HashMap<>();
        parameters.put(AppConstants.FROM_ID, Config.FROM_ID);
        //parameters.put(AppConstants.TO_ID, Config.TO_ID);
        parameters.put(AppConstants.MESSAGE,"offline");
        parameters.put(AppConstants.ONLINE_STATUS, "No");
        parameters.put(AppConstants.NAME, Config.NAME);

        req.UpdateUserStatus(parameters);
    }
}
