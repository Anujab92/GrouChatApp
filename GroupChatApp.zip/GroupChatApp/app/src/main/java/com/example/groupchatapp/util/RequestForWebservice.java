package com.example.groupchatapp.util;

import android.content.Context;
import android.os.AsyncTask;

import com.example.groupchatapp.app.Config;
import com.example.groupchatapp.appconstants.AppConstants;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

/**
 * Created by appyb_000 on 12/11/2016.
 */

public class RequestForWebservice {
    Context mContext;
    private RequestWebserice requestForWebservice;

    public RequestForWebservice(RequestWebserice requestForWebservice, Context mContext) {
        this.requestForWebservice = requestForWebservice;
        this.mContext = mContext;
    }

    public interface RequestWebserice {
        void OnWebserviceReply(String response);
    }

    public void SendAsyncMessage(HashMap<String, String> params) {
        new SendPushAsycn().execute(params);
    }


    public void UpdateUserStatus (HashMap<String, String> params) {
        new SendUserstatus().execute(params);
    }

    private class SendPushAsycn extends AsyncTask<HashMap<String, String>, Void, Void> {

        @Override
        protected Void doInBackground(HashMap<String, String>... params) {
            sendPush(params[0]);
            return null;
        }
    }

    private void sendPush(HashMap<String, String> parameters) {
        try {
            // Prepare JSON containing the GCM message content. What to send and where to send.
            JSONObject jGcmData = new JSONObject();
            JSONObject jData = new JSONObject();
            jData.put(AppConstants.MESSAGE, parameters.get(AppConstants.MESSAGE));
            jData.put(AppConstants.MSG_TYPE,  parameters.get(AppConstants.MSG_TYPE));
            jData.put(AppConstants.FROM_ID,  parameters.get(AppConstants.FROM_ID));
            //jData.put(AppConstants.TO_ID,  parameters.get(AppConstants.TO_ID));
            jData.put(AppConstants.NAME,  parameters.get(AppConstants.NAME));
            // Where to send GCM message.

            jGcmData.put("to", "/topics/global");

            // What to send in GCM message.
            jGcmData.put("data", jData);

            // Create connection to send GCM Message request.
            URL url = new URL("https://fcm.googleapis.com/fcm/send");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Authorization", "key=" + Config.API_KEY);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            // Send GCM message content.
            OutputStream outputStream = conn.getOutputStream();
            outputStream.write(jGcmData.toString().getBytes());

            // Read GCM response.
            InputStream inputStream = conn.getInputStream();
            String resp = convertStreamToString(inputStream);

            if(resp!=null)
                requestForWebservice.OnWebserviceReply(resp);
            //System.out.println(resp);
            System.out.println("Check your device/emulator for notification or logcat for " +
                    "confirmation of the receipt of the GCM message.");
        } catch (IOException e) {
            System.out.println("Unable to send GCM message.");
            System.out.println("Please ensure that API_KEY has been replaced by the server " +
                    "API key, and that the device's registration token is correct (if specified).");
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private class SendUserstatus extends AsyncTask<HashMap<String, String>, Void, Void> {

        @Override
        protected Void doInBackground(HashMap<String, String>... params) {
            sendstatus(params[0]);
            return null;
        }
    }

    private void sendstatus (HashMap<String, String> parameters) {
        try {
            // Prepare JSON containing the GCM message content. What to send and where to send.
            JSONObject jGcmData = new JSONObject();
            JSONObject jData = new JSONObject();
            jData.put(AppConstants.MESSAGE, parameters.get(AppConstants.MESSAGE));
            jData.put(AppConstants.MSG_TYPE,  parameters.get(AppConstants.MSG_TYPE));
            jData.put(AppConstants.FROM_ID,  parameters.get(AppConstants.FROM_ID));
            //jData.put(AppConstants.TO_ID,  parameters.get(AppConstants.TO_ID));
            jData.put(AppConstants.NAME,  parameters.get(AppConstants.NAME));
            jData.put(AppConstants.ONLINE_STATUS,parameters.get(AppConstants.ONLINE_STATUS));
            // Where to send GCM message.

            jGcmData.put("to", "/topics/global");

            // What to send in GCM message.
            jGcmData.put("data", jData);

            // Create connection to send GCM Message request.
            URL url = new URL("https://fcm.googleapis.com/fcm/send");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Authorization", "key=" + Config.API_KEY);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            // Send GCM message content.
            OutputStream outputStream = conn.getOutputStream();
            outputStream.write(jGcmData.toString().getBytes());

            // Read GCM response.
            InputStream inputStream = conn.getInputStream();
            String resp = convertStreamToString(inputStream);

            if(resp!=null)
                requestForWebservice.OnWebserviceReply(resp);
            //System.out.println(resp);
            System.out.println("Check your device/emulator for notification or logcat for " +
                    "confirmation of the receipt of the GCM message.");
        } catch (IOException e) {
            System.out.println("Unable to send GCM message.");
            System.out.println("Please ensure that API_KEY has been replaced by the server " +
                    "API key, and that the device's registration token is correct (if specified).");
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
