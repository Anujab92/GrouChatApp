package com.example.groupchatapp.models;

/**
 * Created by appyb_000 on 12/11/2016.
 */

public class Users {
    String id;
    String name;
    String socketId;

    public String getSocketId() {
        return socketId;
    }

    public void setSocketId(String socketId) {
        this.socketId = socketId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
