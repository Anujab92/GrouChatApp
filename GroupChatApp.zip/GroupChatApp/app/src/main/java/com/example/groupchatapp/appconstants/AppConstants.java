package com.example.groupchatapp.appconstants;

/**
 * Created by appyb_000 on 12/11/2016.
 */

public class AppConstants {
    public static String MyID="8";
    public static String name="test1";
    public static String p_photo="test";

    public static String MESSAGE="message";
    public static String FROM_ID="fromid";
    public static String TO_ID="Toid";
    public static String MSG_TYPE="msgType";
    public static String NAME="name";
    public static String ONLINE_STATUS="isOnline";
}
