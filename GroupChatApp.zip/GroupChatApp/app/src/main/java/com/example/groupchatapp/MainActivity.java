package com.example.groupchatapp;

import android.content.*;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.example.groupchatapp.app.Config;
import com.example.groupchatapp.util.NotificationUtils;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity
       {
           private static final String TAG = MainActivity.class.getSimpleName();
           private BroadcastReceiver mRegistrationBroadcastReceiver;
           private TextView txtRegId, txtMessage;
           EditText name;
           Button submit;

           @Override
           protected void onCreate(Bundle savedInstanceState) {
               super.onCreate(savedInstanceState);
               setContentView(R.layout.activity_main);

               txtRegId = (TextView) findViewById(R.id.txt_reg_id);
               txtMessage = (TextView) findViewById(R.id.txt_push_message);
               name= (EditText) findViewById(R.id.name);
               submit= (Button) findViewById(R.id.submit);

               mRegistrationBroadcastReceiver = new BroadcastReceiver() {
                   @Override
                   public void onReceive(Context context, Intent intent) {

                       // checking for type intent filter
                       if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                           // gcm successfully registered
                           // now subscribe to `global` topic to receive app wide notifications
                           FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);

                       } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                           // new push notification is received
                       }
                   }
               };

               submit.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       String nametxt=name.getText().toString().trim();

                       if(nametxt!=null){
                           Config.NAME=nametxt;

                           int randomPIN = (int)(Math.random()*9000)+1000;
                           Config.FROM_ID =String.valueOf(randomPIN);

                           startActivity(new Intent(MainActivity.this, FcmActivity.class));
                       }
                   }
               });

           }

           // Fetches reg id from shared preferences
           // and displays on the screen
           private void displayFirebaseRegId() {
               SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
               String regId = pref.getString("regId", null);

               Log.e(TAG, "Firebase reg id: " + regId);

               if (!TextUtils.isEmpty(regId)) {
                   txtRegId.setText("Firebase Reg Id: " + regId);
                   new Handler().postDelayed(new Runnable() {
                       @Override
                       public void run() {
                           startActivity(new Intent(MainActivity.this, FcmActivity.class));
                       }
                   }, 1000);
               } else
                   txtRegId.setText("Firebase Reg Id is not received yet!");

           }

           @Override
           protected void onResume() {
               super.onResume();

       /* if (mAdView != null) {
            mAdView.resume();
        }*/

               // register GCM registration complete receiver
               LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                       new IntentFilter(Config.REGISTRATION_COMPLETE));

               // register new push message receiver
               // by doing this, the activity will be notified each time a new message arrives
               LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                       new IntentFilter(Config.PUSH_NOTIFICATION));

               // clear the notification area when the app is opened
               NotificationUtils.clearNotifications(getApplicationContext());
           }

           @Override
           protected void onPause() {
               LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        /*if (mAdView != null) {
            mAdView.pause();
        }*/
               super.onPause();
           }


           /**
            * Called before the activity is destroyed
            */
           @Override
           public void onDestroy() {
        /*if (mAdView != null) {
            mAdView.destroy();
        }*/
               super.onDestroy();
           }

       }
